// Operaciones
let resultado;


// Estos signos se les conoce como operadores, hay para realziar sumas, multiplicaciones, restas y comparar si un número es mayor a otro

// Suma
resultado = numero1 + numero2;
// Resta
resultado = numero1 - numero2;
// Mult
resultado = numero1 * numero2;
// Division
resultado = numero1 / numero2;
// Modulo
resultado = numero1 % numero2;

console.log(resultado);