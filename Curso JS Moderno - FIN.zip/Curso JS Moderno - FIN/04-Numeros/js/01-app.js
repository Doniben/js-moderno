
// Una nota muy importante es que en la consola los números se muestran de diferente color cuando es número que cuando es un string que representa un número

const numero6 = 20;
const numero7 = "20";

// Crear Números

const numero1 = 30;
const numero2 = 20;
const numero3 = 20.20;
const numero4 = .10213;
const numero5 = -3;

// Otra forma de crear número 

const numero8 = new Number(20);
console.log(numero8);
