// Veamos un capitulo Sobre operadores, previamente ya vimos que existen operadores de suma, resta, multiplicación, pero existen unos muy útiles de compraración

const numero1 = 20;
const numero2 = "20";
const numero3 = 30;

// Operador Mayor a 
console.log( numero1 > numero3 );
console.log( numero3 > numero1 );


// Operador Menor que
console.log(numero3 < numero1);

