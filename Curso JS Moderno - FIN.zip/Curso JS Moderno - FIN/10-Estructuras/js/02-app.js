// Veamos otras comparaciones


// No es igual
if(puntaje != 1000) {
    console.log("Si! es diferente!");
}  else {
    console.log("No, no es diferente");
}
// comparador estricto de tipo y valor
if(puntaje === 1000) {
    console.log("Si es igual!");
} else {
    console.log("No no es igual");
}

// comparador estricto de tipo y valor
if(puntaje !== 1000) {
    console.log("Si es DIFERENTE (ESTRICTO) !");
} else {
    console.log("No no es igual");
}
