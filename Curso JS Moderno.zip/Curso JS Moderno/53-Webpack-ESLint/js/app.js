import App from './classes/App.js';

// eslint-disable-nextline
const app = new App();